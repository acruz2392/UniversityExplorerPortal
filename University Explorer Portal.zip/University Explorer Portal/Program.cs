using University_Explorer_Portal.Components;
using University_Explorer_Portal.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.AddHttpClient<ICountryService, CountryService>(c =>
    c.BaseAddress = new Uri("https://countries.dev/"));

builder.Services.AddHttpClient<IUniversityService, IUniversityService>(c =>
    c.BaseAddress = new Uri("https://universities.hipolabs.com/"));

builder.Services.AddHttpClient<IStudentApplicationService, IStudentApplicationService>(c =>
    c.BaseAddress = new Uri("https://edutots.net/api/"));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}
app.UseStatusCodePagesWithReExecute("/not-found", createScopeForStatusCodePages: true);
app.UseHttpsRedirection();

app.UseAntiforgery();

app.MapStaticAssets();
app.MapRazorComponents<Routes>()
    .AddInteractiveServerRenderMode();

app.Run();