﻿using University_Explorer_Portal.Models;

namespace University_Explorer_Portal.Services;

public interface IUniversityService
{
    Task<List<University>> GetByCountryAsync(string country, CancellationToken ct = default);
}