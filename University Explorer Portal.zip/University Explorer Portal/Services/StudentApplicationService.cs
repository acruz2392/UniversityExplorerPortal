﻿using System.Net.Http.Json;
using University_Explorer_Portal.Models;

namespace University_Explorer_Portal.Services;

public class StudentApplicationService(HttpClient http) : IStudentApplicationService
{
    public async Task<List<StudentApplication>> GetAllAsync(CancellationToken ct = default)
        => await http.GetFromJsonAsync<List<StudentApplication>>("studentapplication", ct) ?? new();

    public async Task<StudentApplication?> GetByIdAsync(int id, CancellationToken ct = default)
    {
        var all = await GetAllAsync(ct);
        return all.FirstOrDefault(a => a.Id == id);
    }

    public async Task<StudentApplication?> CreateAsync(StudentApplication application, CancellationToken ct = default)
    {
        var response = await http.PostAsJsonAsync("studentapplication", application, ct);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<StudentApplication>(cancellationToken: ct);
    }

    public async Task UpdateAsync(int id, StudentApplication application, CancellationToken ct = default)
    {
        var response = await http.PutAsJsonAsync($"studentapplication/{id}", application, ct);
        response.EnsureSuccessStatusCode();
    }
}