﻿using University_Explorer_Portal.Models;

namespace University_Explorer_Portal.Services;

public interface ICountryService
{
    Task<List<Country>> GetCountriesAsync(CancellationToken ct = default);
}
