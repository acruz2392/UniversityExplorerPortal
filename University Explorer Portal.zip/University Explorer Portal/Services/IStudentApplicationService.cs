﻿using University_Explorer_Portal.Models;

namespace University_Explorer_Portal.Services;

public interface IStudentApplicationService
{
    Task<List<StudentApplication>> GetAllAsync(CancellationToken ct = default);
    Task<StudentApplication?> GetByIdAsync(int id, CancellationToken ct = default);
    Task<StudentApplication?> CreateAsync(StudentApplication application, CancellationToken ct = default);
    Task UpdateAsync(int id, StudentApplication application, CancellationToken ct = default);
}
