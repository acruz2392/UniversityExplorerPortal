﻿using University_Explorer_Portal.Models;

namespace University_Explorer_Portal.Services;

public class CountryService(HttpClient http) : ICountryService
{
    public async Task<List<Country>> GetCountriesAsync(CancellationToken ct = default)
    {
        var countries = await http.GetFromJsonAsync<List<Country>>("countries", ct);
        return countries?.OrderBy(c => c.Name).ToList() ?? new();
    }
}