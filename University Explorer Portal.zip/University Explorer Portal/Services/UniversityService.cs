﻿using System.Net.Http.Json;
using University_Explorer_Portal.Models;

namespace University_Explorer_Portal.Services;

public class UniversityService(HttpClient http) : IUniversityService
{
    public async Task<List<University>> GetByCountryAsync(string country, CancellationToken ct = default)
    {
        var url = $"search?country={Uri.EscapeDataString(country)}";
        return await http.GetFromJsonAsync<List<University>>(url, ct) ?? new();
    }
}
