﻿// Models/StudentApplication.cs
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace University_Explorer_Portal.Models;

public class StudentApplication
{
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [Required(ErrorMessage = "Student name is required.")]
    [StringLength(100, MinimumLength = 2)]
    [JsonPropertyName("studentName")]
    public string StudentName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email is required.")]
    [EmailAddress(ErrorMessage = "Enter a valid email address.")]
    [JsonPropertyName("emailAddress")]
    public string EmailAddress { get; set; } = string.Empty;

    [Required(ErrorMessage = "Country is required.")]
    [JsonPropertyName("country")]
    public string Country { get; set; } = string.Empty;

    [Required(ErrorMessage = "University name is required.")]
    [JsonPropertyName("universityName")]
    public string UniversityName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Course name is required.")]
    [JsonPropertyName("courseName")]
    public string CourseName { get; set; } = string.Empty;

    [JsonPropertyName("applicationDate")]
    public DateTime ApplicationDate { get; set; } = DateTime.Today;
}