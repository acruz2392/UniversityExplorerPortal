﻿// Models/University.cs
using System.Text.Json.Serialization;

namespace University_Explorer_Portal.Models;

public class University
{
    [JsonPropertyName("name")] public string Name { get; set; } = string.Empty;
    [JsonPropertyName("country")] public string Country { get; set; } = string.Empty;
    [JsonPropertyName("alpha_two_code")] public string? AlphaTwoCode { get; set; }
    [JsonPropertyName("state-province")] public string? StateProvince { get; set; }
    [JsonPropertyName("domains")] public List<string> Domains { get; set; } = new();
    [JsonPropertyName("web_pages")] public List<string> WebPages { get; set; } = new();

    public string? Website => WebPages.FirstOrDefault();
}
