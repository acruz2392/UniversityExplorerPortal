﻿// Models/Country.cs
using System.Text.Json.Serialization;

namespace University_Explorer_Portal.Models;

public class Country
{
    [JsonPropertyName("name")] public string Name { get; set; } = string.Empty;
    [JsonPropertyName("capital")] public string? Capital { get; set; }
    [JsonPropertyName("region")] public string? Region { get; set; }
    [JsonPropertyName("population")] public long Population { get; set; }
    [JsonPropertyName("flag")] public string? Flag { get; set; }
}
